<!DOCTYPE html>
<html lang="en">

<?php include 'header.php';?>


<section class="page-content">
<div class="wrapper">
<div class="page-header">
<h1>Add Media</h1>
</div>

<div class="item-wrap">
<form action="#" method="post" enctype="multipart/form-data">
<div class="row">
<div class="col-xs-12 col-sm-12"><input type="file" name="files[]" id="filer_input2" multiple="multiple"></div>
<div class="col-xs-6 col-xs-offset-3 col-sm-4 col-sm-offset-4"><button type="submit" class="btn btn-primary btn-lg btn-block"><i class="fa fa-cloud-upload"></i>Upload</button></div>
</form>
</div>
</div>
</section>


<?php include 'footer.php';?>
</body>
</html>